#include <stdio.h>
#include <ncurses.h>
#define UP 'u'
#define DOWN 'd'
#define LEFT 'l'
#define RIGHT 'r'

struct snake
{
	// {y,x}
	int pos_head[2];
	int pos_neck[2];
	int pos_body[2];
	int pos_leg[2];
	int pos_tail[2];
	char (*left) (struct snake*);
	char (*right) (struct snake*);
	char (*up) (struct snake*);
	char (*down) (struct snake*);
};

char goLeft(struct snake* ptr_snake)
{
	if(mvinch(ptr_snake->pos_head[0], (ptr_snake->pos_head[1]+COLS-1)%COLS) != '*')
	{   
		ptr_snake->pos_tail[0] = ptr_snake->pos_leg[0];
		ptr_snake->pos_tail[1] = ptr_snake->pos_leg[1];
		ptr_snake->pos_leg[0] = ptr_snake->pos_body[0];
		ptr_snake->pos_leg[1] = ptr_snake->pos_body[1];
		ptr_snake->pos_body[0] = ptr_snake->pos_neck[0];
		ptr_snake->pos_body[1] = ptr_snake->pos_neck[1];
		ptr_snake->pos_neck[0] = ptr_snake->pos_head[0];
		ptr_snake->pos_neck[1] = ptr_snake->pos_head[1];
		ptr_snake->pos_head[1] = (ptr_snake->pos_head[1]+COLS-1)%COLS;
		return 1;
	}
	else
		return 0;
}

char goRight(struct snake* ptr_snake)
{
	if(mvinch(ptr_snake->pos_head[0],(ptr_snake->pos_head[1]+1)%COLS) != '*')
	{
		ptr_snake->pos_tail[0] = ptr_snake->pos_leg[0];
		ptr_snake->pos_tail[1] = ptr_snake->pos_leg[1];
		ptr_snake->pos_leg[0] = ptr_snake->pos_body[0];
		ptr_snake->pos_leg[1] = ptr_snake->pos_body[1];
		ptr_snake->pos_body[0] = ptr_snake->pos_neck[0];
		ptr_snake->pos_body[1] = ptr_snake->pos_neck[1];
		ptr_snake->pos_neck[0] = ptr_snake->pos_head[0];
		ptr_snake->pos_neck[1] = ptr_snake->pos_head[1];
		ptr_snake->pos_head[1] = (ptr_snake->pos_head[1]+1)%COLS;
		return 1;
	}
	else
		return 0;
}

char goUp(struct snake* ptr_snake)
{
	if(mvinch((ptr_snake->pos_head[0]+LINES-1)%LINES, ptr_snake->pos_head[1]) != '*')
	{
		ptr_snake->pos_tail[0] = ptr_snake->pos_leg[0];
		ptr_snake->pos_tail[1] = ptr_snake->pos_leg[1];
		ptr_snake->pos_leg[0] = ptr_snake->pos_body[0];
		ptr_snake->pos_leg[1] = ptr_snake->pos_body[1];
		ptr_snake->pos_body[0] = ptr_snake->pos_neck[0];
		ptr_snake->pos_body[1] = ptr_snake->pos_neck[1];
		ptr_snake->pos_neck[0] = ptr_snake->pos_head[0];
		ptr_snake->pos_neck[1] = ptr_snake->pos_head[1];
		ptr_snake->pos_head[0] = (ptr_snake->pos_head[0]+LINES-1)%LINES;
		return 1;
	}
	else
		return 0;
}

char goDown(struct snake* ptr_snake)
{
	if(mvinch((ptr_snake->pos_head[0]+1)%LINES, ptr_snake->pos_head[1]) != '*')
	{
		ptr_snake->pos_tail[0] = ptr_snake->pos_leg[0];
		ptr_snake->pos_tail[1] = ptr_snake->pos_leg[1];
		ptr_snake->pos_leg[0] = ptr_snake->pos_body[0];
		ptr_snake->pos_leg[1] = ptr_snake->pos_body[1];
		ptr_snake->pos_body[0] = ptr_snake->pos_neck[0];
		ptr_snake->pos_body[1] = ptr_snake->pos_neck[1];
		ptr_snake->pos_neck[0] = ptr_snake->pos_head[0];
		ptr_snake->pos_neck[1] = ptr_snake->pos_head[1];
		ptr_snake->pos_head[0] = (ptr_snake->pos_head[0]+1)%LINES;
		return 1;
	}
	else
		return 0;
}

int main()
{
	initscr();
	noecho();
	curs_set(0);
	keypad(stdscr, TRUE);
	if (COLS < 11 || LINES < 11)
	{
		printf("small screen");
		return 0;
	}
	int pos_center[2] = {LINES/2, COLS/2}; 
	struct snake snakes[4] = { // pos_head, pos_neck, pos_body, pos_leg, pos_tail, left, right, up, down
		{
			{pos_center[0], pos_center[1]-1},
			{0, 0},
			{0, 0},
			{0, 0},
			{0, 0},
			goDown, goUp, goLeft, goRight
		},
		{
			{pos_center[0]-1, pos_center[1]}, 
			{0, 0},
			{0, 0},
			{0, 0},
			{0, 0},
			goLeft, goRight, goUp, goDown
		},  
		{
			{pos_center[0], pos_center[1]+1},
			{0, 0},
			{0, 0},
			{0, 0},
			{0, 0},
			goUp, goDown, goRight, goLeft
		},
		{
			{pos_center[0]+1, pos_center[1]},
			{0, 0},
			{0, 0},
			{0, 0},
			{0, 0},
			goRight, goLeft, goDown, goUp
		}
	};
	for(int i = -1; i < 2; i++)
	{
		mvaddch(pos_center[0]+i, pos_center[1], '*');
	}
	mvaddstr(pos_center[0], pos_center[1]-1, "* *");
	int ch = 0;
	char result;
	int tmp[2];
	while(ch != 'q')
	{
		refresh();
		ch = getch();
		for(int i = 0; i < 4; i++)
		{
			switch(ch)
			{
				case KEY_LEFT:
					tmp[0] = snakes[i].pos_tail[0];
					tmp[1] = snakes[i].pos_tail[1];
					result = snakes[i].left(&snakes[i]);
					if(result == 1)
					{
						mvaddch(tmp[0], tmp[1], ' ');
						mvaddch(snakes[i].pos_head[0], snakes[i].pos_head[1], '*');
					}
					break;

				case KEY_RIGHT:
					tmp[0] = snakes[i].pos_tail[0];
					tmp[1] = snakes[i].pos_tail[1];
					result = snakes[i].right(&snakes[i]);
					if(result == 1)
					{
						mvaddch(tmp[0], tmp[1], ' ');
						mvaddch(snakes[i].pos_head[0], snakes[i].pos_head[1], '*');
					}
					break;

				case KEY_DOWN:
					tmp[0] = snakes[i].pos_tail[0];
					tmp[1] = snakes[i].pos_tail[1];
					result = snakes[i].down(&snakes[i]);
					if(result == 1)
					{
						mvaddch(tmp[0], tmp[1], ' ');
						mvaddch(snakes[i].pos_head[0], snakes[i].pos_head[1], '*');
					}
					break;

				case KEY_UP:
					tmp[0] = snakes[i].pos_tail[0];
					tmp[1] = snakes[i].pos_tail[1];
					result = snakes[i].up(&snakes[i]);
					if(result == 1)
					{
						mvaddch(tmp[0], tmp[1], ' ');
						mvaddch(snakes[i].pos_head[0], snakes[i].pos_head[1], '*');
					}
					break;

				default:
					break;
			}
		}
	}
	endwin();
	return 0;
}

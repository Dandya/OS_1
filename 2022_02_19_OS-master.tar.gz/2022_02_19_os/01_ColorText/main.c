#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("\033[4;37;41mSimple\033[0m \033[5;31;47mcolor\033[0m \033[2;32;46mtext\033[0m\n");
    return 0;
}

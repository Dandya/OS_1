#include <time.h>
#include <stdlib.h>
#include <stdio.h>

#include "sched.h"

static struct process_info
{
    int id;
    int time_end;
    struct process_info *next;
} *first_proc, *next_proc, *prev_proc, *tmp_proc, *last_added_proc;

static int needed_search;

static int search_fast_process()
{
    if(first_proc == NULL)
        return -1;

    tmp_proc = prev_proc;
    next_proc = first_proc;
    
    do
    {
        if (next_proc->time_end < tmp_proc->time_end)
        {
            tmp_proc = next_proc;
        }
        next_proc = next_proc->next;
    } while(next_proc != NULL);
    
    if (tmp_proc->id != prev_proc->id || tmp_proc->time_end == 0)
        needed_search = 1;
    else
        needed_search = 0;
        
    prev_proc = tmp_proc;
    return tmp_proc->id;
}

static int delete_process(struct process_info *proc)
{
    if(first_proc == proc)
    {
        tmp_proc = first_proc;
        first_proc = first_proc->next;
        free(tmp_proc);
        return 0;
    }

    tmp_proc = first_proc;
    
    while(tmp_proc->next != proc)
        tmp_proc = tmp_proc->next;
        
    tmp_proc->next = proc->next;
    
    free(proc);
    return 0;
}

int sched_init(void)
{
    first_proc = NULL;
    return 0;
}

void sched_clean(void)
{
    tmp_proc = first_proc;
    
    while(tmp_proc != NULL)
    {
        prev_proc = tmp_proc;
        tmp_proc = tmp_proc->next;
        free(prev_proc);
    }
        
}

int add_proc(void)
{
    if(first_proc == NULL)
    {
        first_proc = (struct process_info*)malloc(sizeof(struct process_info));
        first_proc->id = 0;
        prev_proc = first_proc;
        last_added_proc = first_proc;
        return 0;
    }

    tmp_proc = (struct process_info*)malloc(sizeof(struct process_info));
    tmp_proc->time_end = 0;
    tmp_proc->next = NULL;
    tmp_proc->id = last_added_proc->id + 1;
    last_added_proc->next = tmp_proc;
    last_added_proc = tmp_proc;

    return tmp_proc->id;

}

int sched(int time, int cont)
{
  if(first_proc == NULL)
        return -1;

  if (cont == 0 && time != 0) 
  {
    delete_process(prev_proc);
    prev_proc = first_proc;
    return search_fast_process();
  }
  
  prev_proc->time_end = cont;
  
  
  return needed_search? search_fast_process() : prev_proc->id;
}

int sched_fin(void)
{
    sched_clean();
    return 0;
}



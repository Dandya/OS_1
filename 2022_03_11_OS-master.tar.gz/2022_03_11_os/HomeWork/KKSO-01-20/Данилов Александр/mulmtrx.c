#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

char* read_num(FILE* file);
long long* convert_fmtrx_to_mtrx(void *args);
void mul_line_on_mtrx(void *args);
int convert_mtrx_to_fmtrx(char* file_name, long long *mtrx, long long* size_mtrx);

struct args_convert
{
    FILE* fmtrx;
    long long *size_mtrx;
};

struct args_mul
{
    long long *ptr_line_mtrx_3;
    long long *ptr_line_mtrx_1;
    long long *mtrx_2;
    long long *size_mtrx_2;   
};

int main(int argc, char* argv[])
{
    if(argc < 3)
    {
        fprintf(stderr, "USE: mulmtrx.exe matrix_1 matrix_2 result_matrix\n");
        return 1;
    }

    FILE *fmtrx_1, *fmtrx_2;
    if( (fmtrx_1 = fopen(argv[1], "r")) == NULL || 
        (fmtrx_2 = fopen(argv[2], "r")) == NULL )
    {
        fprintf(stderr, "Inputted uncorrect file name\n");
        return 2;
    }
    long long size_mtrx_1[2], size_mtrx_2[2], *mtrx_1, *mtrx_2;
    
    pthread_t tid; 
    pthread_attr_t attr;

    if( pthread_attr_init(&attr) != 0 )
    {
        fprintf(stderr, "Error of init attr\nLine: %d\n", __LINE__);
        fclose(fmtrx_1);
        fclose(fmtrx_2);
        return 3;
    }

    if (pthread_create(&tid,&attr,(void *)convert_fmtrx_to_mtrx, &(struct args_convert){fmtrx_1, size_mtrx_1} ) != 0 )
    { 
        fprintf(stderr, "Error of create thread\nLine: %d\n", __LINE__);
        fclose(fmtrx_1);
        fclose(fmtrx_2);
        return 4;
    }

    
    mtrx_2 = convert_fmtrx_to_mtrx(&(struct args_convert){fmtrx_2, size_mtrx_2});
    if( mtrx_2 == NULL )
    {
        fprintf(stderr, "Error of create matrix 2\n");
        fclose(fmtrx_1);
        fclose(fmtrx_2);
        return 5;
    } 

    if( pthread_join(tid, (void *)&mtrx_1) != 0 )
    {
        fprintf(stderr, "Error of working thread\nLine: %d\n", __LINE__);
        free(mtrx_2);
        fclose(fmtrx_1);
        fclose(fmtrx_2);
        return 6;
    }
    if( mtrx_1 == NULL )
    {
        fprintf(stderr, "Error of create matrix 1\n");
        free(mtrx_2);
        fclose(fmtrx_1);
        fclose(fmtrx_2);
        return 5;
    }

    fclose(fmtrx_1);
    fclose(fmtrx_2);

    if(size_mtrx_1[1] != size_mtrx_2[0] )
    {
        fprintf(stderr, "Uncorrect sizes\n");
        free(mtrx_1);
        free(mtrx_2);
        return 2;
    }


    long long * mtrx_3 = (long long*)malloc(size_mtrx_1[0]*size_mtrx_2[1]*8);
    if( mtrx_3 == NULL )
    {
        fprintf(stderr, "Error of creating matrix 3\n");
        return 8;
    }

    pthread_t tid_line[size_mtrx_1[0]-1];
    struct args_mul args[size_mtrx_1[0]-1];

    for(int i = 0; i < size_mtrx_1[0] - 1; i++)
    {
        args[i].ptr_line_mtrx_3 = mtrx_3 + i*size_mtrx_2[1];
        args[i].ptr_line_mtrx_1 =  mtrx_1 + i*size_mtrx_1[1]; 
        args[i].mtrx_2 = mtrx_2; 
        args[i].size_mtrx_2 = size_mtrx_2;
    }

    for(int i = 0; i < size_mtrx_1[0] - 1; i++)
    {
        if ( pthread_create(tid_line + i, &attr,(void *)mul_line_on_mtrx, args + i) != 0 ) // &((struct args_mul){mtrx_3 + i*size_mtrx_2[1], mtrx_1 + i*size_mtrx_1[1], mtrx_2, size_mtrx_2})
        {
            fprintf(stderr, "Error of create thread\nLine: %d\n", __LINE__);
            free(mtrx_1);
            free(mtrx_2);
            free(mtrx_3);
            return 4;
        }
    }

    mul_line_on_mtrx(&(struct args_mul){mtrx_3 + (size_mtrx_1[0] - 1)*size_mtrx_2[1], 
       mtrx_1 + (size_mtrx_1[0] - 1)*size_mtrx_1[1], mtrx_2, size_mtrx_2});

    for(int i = 0; i < size_mtrx_1[0] - 1; i++)
    {
        if ( pthread_join(tid_line[i], NULL) != 0 )
        {
            fprintf(stderr, "Error of working thread\nLine: %d\n", __LINE__);
            free(mtrx_1);
            free(mtrx_2);
            free(mtrx_3);
            return 4;
        }
    }

    size_mtrx_1[1] = size_mtrx_2 [1]; // next size_mtrx_1 is size mtrx_3

    if( argc == 3 )
    {
        convert_mtrx_to_fmtrx("matrix.out", mtrx_3, size_mtrx_1);
    } else
    {
        convert_mtrx_to_fmtrx(argv[3], mtrx_3, size_mtrx_1);
    }


    free(mtrx_1);
    free(mtrx_2);
    free(mtrx_3);
    return 0;
}

char* read_num(FILE* file) 
{
    char* str_num = (char*)malloc(21); // LLONG_MAX = +9223372036854775807
    if (str_num == NULL)
    {
        return NULL;
    }

    int i = 0;
    str_num[i] = fgetc(file);
    if( !(str_num[i] >= '0' && str_num[i] <= '9' || 
        str_num[i] == '-' || str_num[i] == '+' ) )
    {
        fprintf(stderr, "Uncorrect matrix\nLine: %d\n", __LINE__);
        return NULL;
    }

    while( str_num[i] != ' ' && str_num[i] != '\n' &&  str_num[i] != 13 ) // "str_num[i] != 13" need for support CRLF 
    {
        if( !(str_num[i] >= '0' && str_num[i] <= '9' || 
            str_num[i] == '-' || str_num[i] == '+' ) || 
            i == 20)
        {
            fprintf(stderr, "Uncorrect matrix. number =  %d, i = %d \nLine: %d\n", str_num[i], i, __LINE__);
            return NULL;
        }
        i++;
        str_num[i] = fgetc(file);
    }
    if ( str_num[i] == 13 ) 
    {
        if (fgetc(file) != '\n')
        {
            fprintf(stderr, "Uncorrect matrix. number =  %d, i = %d \nLine: %d\n", str_num[i], i, __LINE__);
            return NULL;
        }
    }
    str_num[20] = '\0';
    return str_num;
}

long long* convert_fmtrx_to_mtrx(void *args)
{
    FILE* fmtrx = ((struct args_convert*)args)->fmtrx;
    long long *size_mtrx = ((struct args_convert*)args)-> size_mtrx;

    // reading first size number
    char* str_num = read_num(fmtrx);
    if( str_num == NULL )
    {
        fprintf(stderr, "Error of read number\nLine: %d\n", __LINE__);
        return NULL;
    }
    size_mtrx[0] = atoll(str_num);
    free(str_num);
    // checking the size format
    if ( fgetc(fmtrx) != 'x' )
    {
        fprintf(stderr, "Uncorrect matrix\nLine: %d\n",  __LINE__);
        return NULL;
    } 
    else if ( fgetc(fmtrx) != ' ')
    {
        fprintf(stderr, "Uncorrect matrix\nLine: %d\n", __LINE__);
        return NULL;
    }
    // reading second size number
    str_num = read_num(fmtrx);
    if( str_num == NULL )
    {
        fprintf(stderr, "Error of read number\nLine: %d\n", __LINE__);
        return NULL;
    }
    size_mtrx[1] = atoll(str_num);
    free(str_num);
    // getting count of numbers
    long long count_numbers = size_mtrx[0]*size_mtrx[1];
    if ( count_numbers <= 0 )
    {
        fprintf(stderr, "Uncorrect size\n");
        return NULL;
    }

    long long *mtrx = (long long*)malloc(count_numbers*8);
    if( mtrx == NULL )
    {   
        fprintf(stderr, "Error of creating matrix\n");
        return NULL;
    }

    for(int i = count_numbers; i != 0; i--)
    {
        str_num = read_num(fmtrx);
        if( str_num == NULL )
        {
            fprintf(stderr, "Error of read number\nLine: %d\n", __LINE__);
            return NULL;
        }
        mtrx[count_numbers - i] = atoll(str_num);
        free(str_num);
    }

    return mtrx;
}

void mul_line_on_mtrx(void *args)
{
    long long *ptr_line_mtrx_3 = ((struct args_mul*)args)->ptr_line_mtrx_3;
    long long *ptr_line_mtrx_1 = ((struct args_mul*)args)->ptr_line_mtrx_1;
    long long *mtrx_2 = ((struct args_mul*)args)->mtrx_2;
    long long *size_mtrx_2 = ((struct args_mul*)args)->size_mtrx_2;

    for (int i = 0; i < size_mtrx_2[1]; i++) 
    {
        ptr_line_mtrx_3[i] = 0; // clear memory
    }

    for (int i = 0, j = 0; i < size_mtrx_2[1]; j++)
    {
        if ( j == size_mtrx_2[0] )
        {
            j = -1;
            i++;
            continue;
        }
        ptr_line_mtrx_3[i] += ptr_line_mtrx_1[j] * mtrx_2[j*size_mtrx_2[1] + i];
    }
}

int convert_mtrx_to_fmtrx(char* file_name, long long *mtrx, long long* size_mtrx)
{
    FILE *file = fopen(file_name, "w");
    
    fprintf(file, "%lld x %lld\n", size_mtrx[0], size_mtrx[1]);

    for(int i = 0, j = 0; i < size_mtrx[0]; j++)
    {
        if ( j == size_mtrx[1] - 1 )
        {
            fprintf(file, "%lld\n", mtrx[i*size_mtrx[1] + j]);
            j = -1;
            i++;
            continue;
        }
        fprintf(file, "%lld ", mtrx[i*size_mtrx[1] + j]);
    }
    fclose(file);
}